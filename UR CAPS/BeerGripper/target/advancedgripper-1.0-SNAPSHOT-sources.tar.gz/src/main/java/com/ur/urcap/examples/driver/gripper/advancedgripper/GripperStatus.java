package com.ur.urcap.examples.driver.gripper.advancedgripper;

public class GripperStatus {
    // public static RobotClient client = new RobotClient("192.168.0.20", 2050);
	public static String gripperPosStatus = "open";
}